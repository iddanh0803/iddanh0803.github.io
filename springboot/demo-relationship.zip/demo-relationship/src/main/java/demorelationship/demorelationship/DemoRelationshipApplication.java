package demorelationship.demorelationship;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoRelationshipApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoRelationshipApplication.class, args);
	}

}
